from numutils.n2w import n2w

n = n2w(0)
