=====
Usage
=====

To use n2w in a project::

    import n2w
