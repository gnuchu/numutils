=======
History
=======

0.1.0 (2021-12-18)
------------------

* First release on PyPI.
