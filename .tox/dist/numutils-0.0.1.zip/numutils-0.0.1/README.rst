===
numutils.n2w
===


.. image:: https://img.shields.io/pypi/v/n2w.svg
        :target: https://pypi.python.org/pypi/n2w

.. image:: https://img.shields.io/travis/gnuchu/n2w.svg
        :target: https://travis-ci.com/gnuchu/n2w

.. image:: https://readthedocs.org/projects/n2w/badge/?version=latest
        :target: https://n2w.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status


.. image:: https://pyup.io/repos/github/gnuchu/n2w/shield.svg
     :target: https://pyup.io/repos/github/gnuchu/n2w/
     :alt: Updates



helper library that converts numbers to words


* Free software: MIT license
* Documentation: https://n2w.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
